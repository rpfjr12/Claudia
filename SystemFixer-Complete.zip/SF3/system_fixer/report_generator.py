"""
report_generator.py — generates professional bug-bounty-ready reports.
Each report is a complete submission-ready Markdown document.
"""
import os
import json
from datetime import datetime, timezone
from collections import defaultdict

OUTPUT_DIR = "reports"

SEVERITY_ICONS = {
    "CRITICAL": "🔴",
    "HIGH":     "🟠",
    "MEDIUM":   "🟡",
    "LOW":      "🟢",
    "UNRATED":  "⚪",
}

PAYOUT_ESTIMATES = {
    "CRITICAL": "$3,000 – $20,000+",
    "HIGH":     "$500 – $5,000",
    "MEDIUM":   "$100 – $1,000",
    "LOW":      "$50 – $300",
    "UNRATED":  "$0 – $100",
}


def _fmt_evidence(evidence: dict) -> str:
    if not evidence:
        return "_No evidence recorded._"
    lines = ["```"]
    for k, v in evidence.items():
        if k == "all_headers":
            lines.append(f"all_headers: {{...{len(v)} headers...}}")
        elif isinstance(v, dict):
            lines.append(f"{k}: {json.dumps(v)}")
        else:
            lines.append(f"{k}: {v}")
    lines.append("```")
    return "\n".join(lines)


def generate_finding_report(finding: dict) -> str:
    title        = finding.get("title", "Untitled Finding")
    program      = finding.get("program", "Unknown Program")
    target       = finding.get("target", "Unknown Target")
    sev          = finding.get("severity", "UNRATED")
    icon         = SEVERITY_ICONS.get(sev, "⚪")
    desc         = finding.get("description", "No description provided.")
    repro        = finding.get("reproduction_steps", "No reproduction steps provided.")
    impact       = finding.get("impact", "No impact provided.")
    money_score  = finding.get("money_score", 0)
    fingerprint  = finding.get("fingerprint", "")
    vuln_class   = finding.get("vuln_class", "")
    evidence     = finding.get("evidence", {})
    source       = finding.get("source", "scanner")
    intel        = finding.get("intelligence", {})
    tags         = intel.get("tags", [])
    payout_est   = PAYOUT_ESTIMATES.get(sev, "$0")
    now          = datetime.now(timezone.utc).isoformat()

    lines = [
        f"# {icon} {title}",
        f"",
        f"> **Program:** {program}  ",
        f"> **Target:** `{target}`  ",
        f"> **Severity:** {icon} {sev}  ",
        f"> **Estimated Payout:** {payout_est}  ",
        f"> **Money Score:** {money_score}/100  ",
        f"> **Generated:** {now} UTC  ",
        f"> **Fingerprint:** `{fingerprint}`  ",
        f"",
        f"---",
        f"",
        f"## Summary",
        f"",
        desc,
        f"",
        f"---",
        f"",
        f"## Impact",
        f"",
        impact,
        f"",
        f"---",
        f"",
        f"## Steps to Reproduce",
        f"",
        repro,
        f"",
        f"---",
        f"",
        f"## Evidence",
        f"",
        f"**Source:** `{source}`  ",
        f"**Vulnerability Class:** `{vuln_class or 'N/A'}`  ",
        f"**Intelligence Tags:** {', '.join(f'`{t}`' for t in tags) if tags else '_none_'}  ",
        f"",
        _fmt_evidence(evidence),
        f"",
        f"---",
        f"",
        f"## Suggested Fix",
        f"",
        _suggest_fix(vuln_class, title),
        f"",
        f"---",
        f"",
        f"## Bug Bounty Submission Notes",
        f"",
        f"- This finding was discovered and verified automatically by SystemFixer.",
        f"- The evidence above was captured during a live HTTP scan.",
        f"- No manual exploitation was performed; all checks are passive/read-only.",
        f"- Estimated payout range based on platform averages for {sev} findings.",
        f"",
    ]
    return "\n".join(lines)


def _suggest_fix(vuln_class: str, title: str) -> str:
    fixes = {
        "header_misconfiguration": (
            "Add the missing security header to all HTTP responses. "
            "For web servers:\n\n"
            "**Nginx:** `add_header Header-Name 'value' always;`  \n"
            "**Apache:** `Header always set Header-Name 'value'`  \n"
            "**Express.js:** Use the `helmet` middleware package."
        ),
        "cors": (
            "Replace `Access-Control-Allow-Origin: *` or echo-origin logic with "
            "an explicit allowlist:\n\n"
            "```python\n"
            "ALLOWED_ORIGINS = {'https://app.example.com'}\n"
            "if request.origin in ALLOWED_ORIGINS:\n"
            "    response.headers['Access-Control-Allow-Origin'] = request.origin\n"
            "```\n"
            "Never combine `Allow-Credentials: true` with wildcard origins."
        ),
        "jwt": (
            "Explicitly reject the `none` algorithm:\n\n"
            "```python\n"
            "jwt.decode(token, key, algorithms=['HS256'])  # never include 'none'\n"
            "```\n"
            "Use an approved library with a hardcoded algorithm allowlist."
        ),
        "open_redirect": (
            "Validate redirect destinations against an explicit allowlist:\n\n"
            "```python\n"
            "ALLOWED = {'https://app.example.com'}\n"
            "if dest not in ALLOWED:\n"
            "    dest = '/'\n"
            "```\n"
            "Never redirect to user-supplied URLs without strict validation."
        ),
        "ssrf": (
            "Validate URLs against an allowlist of permitted hosts before fetching:\n\n"
            "```python\n"
            "from ipaddress import ip_address, ip_network\n"
            "# Block RFC1918, link-local, loopback\n"
            "if ip_network(resolved_ip).is_private:\n"
            "    raise ValueError('SSRF blocked')\n"
            "```"
        ),
        "info_disclosure": (
            "Remove server version information from response headers:\n\n"
            "**Nginx:** `server_tokens off;`  \n"
            "**Apache:** `ServerTokens Prod` and `ServerSignature Off`  \n"
            "**Express.js:** `app.disable('x-powered-by')`"
        ),
        "insecure_cookie": (
            "Set Secure, HttpOnly, and SameSite on all session cookies:\n\n"
            "```\n"
            "Set-Cookie: session=VALUE; Secure; HttpOnly; SameSite=Lax; Path=/\n"
            "```"
        ),
    }
    return fixes.get(
        vuln_class,
        "Follow OWASP security hardening guidance for this vulnerability class. "
        "Consult the relevant CWE entry for detailed remediation steps."
    )


def generate_program_report(program_name: str, findings: list) -> str:
    now    = datetime.now(timezone.utc).isoformat()
    counts = defaultdict(int)
    for f in findings:
        counts[f.get("severity", "UNRATED")] += 1

    lines = [
        f"# {program_name} — Security Findings Report",
        f"",
        f"**Generated:** {now} UTC  ",
        f"**Program:** {program_name}  ",
        f"**Total Findings:** {len(findings)}  ",
        f"",
        f"| Severity | Count |",
        f"|----------|-------|",
    ]
    for sev in ["CRITICAL", "HIGH", "MEDIUM", "LOW", "UNRATED"]:
        if counts[sev]:
            lines.append(f"| {SEVERITY_ICONS[sev]} {sev} | {counts[sev]} |")

    lines += ["", "---", "", "## Individual Findings", ""]

    for i, f in enumerate(findings, 1):
        sev  = f.get("severity", "UNRATED")
        icon = SEVERITY_ICONS.get(sev, "⚪")
        lines.append(generate_finding_report(f))
        lines.append("")

    return "\n".join(lines)


def write_report_file(program_name: str, findings: list) -> str:
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    date      = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    safe_name = program_name.replace("/", "_").replace(" ", "-")
    filename  = os.path.join(OUTPUT_DIR, f"{safe_name}-{date}.md")
    content   = generate_program_report(program_name, findings)
    with open(filename, "w", encoding="utf-8") as fh:
        fh.write(content)
    print(f"[report_generator] Wrote: {filename}")
    return filename


def generate_reports(findings: list):
    """Entry point called by pipeline.py"""
    print(f"[report_generator] Generating reports for {len(findings)} findings...")
    by_program = defaultdict(list)
    for f in findings:
        by_program[f.get("program", "Unknown")].append(f)
    for program_name, program_findings in sorted(by_program.items()):
        write_report_file(program_name, program_findings)
    print(f"[report_generator] Generated {len(by_program)} program reports")


# Backwards compatibility shims
def generate_markdown_report(finding):
    return generate_finding_report(finding)
