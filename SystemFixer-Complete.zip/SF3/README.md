# SystemFixer — Autonomous Vulnerability Analysis System

A fully autonomous bug bounty vulnerability scanner and reporting pipeline.
Runs daily via GitHub Actions. Zero human intervention required.

## Quick Start

```bash
# Install dependencies
pip install -r requirements.txt

# Run everything (scan + pipeline + reports + dashboard)
python main.py

# Scanner only
python main.py --scan-only

# Pipeline only (process existing scan data)
python main.py --pipe-only

# Show current status
python main.py --status
```

## View the Command Center

After running `python main.py`, open `dashboard/index.html` in your browser.

The Command Center includes:
- **Dashboard** — severity charts, vuln class breakdown, findings over time, program cards
- **Explorer** — filterable/searchable findings table with detail panels
- **Reports** — links to all generated Markdown reports
- **Submissions** — track bug bounty submissions and earnings (stored locally)
- **Copilot** — chat assistant for querying findings

## GitHub Actions (Fully Automated)

| Workflow | Schedule | Trigger |
|---|---|---|
| `🔍 Daily Scan` | 05:00 UTC daily | cron + manual |
| `⚙️ Run Pipeline` | 06:30 UTC daily | after scan completes |
| `📋 Fetch Programs` | 04:00 UTC Mondays | cron + manual |
| `🚀 Full Run` | manual only | workflow_dispatch |

Push to GitHub and the system runs itself forever.

## What Gets Checked (Auto-Verified)

All findings include real HTTP evidence captured live:

- **Missing security headers** — HSTS, CSP, X-Frame-Options, X-Content-Type-Options, Referrer-Policy, Permissions-Policy
- **CORS misconfiguration** — reflected Origin, wildcard + credentials
- **Server version disclosure** — Server / X-Powered-By headers
- **Insecure cookie attributes** — missing Secure, HttpOnly, SameSite

Every finding includes: status code, response headers, exact HTTP evidence.
No synthetic data. No manual verification needed.

## Output Files

| File | Contents |
|---|---|
| `data/scan_results.json` | Raw scanner output |
| `output/final_findings.json` | Processed, scored, ranked findings |
| `reports/<Program>-<date>.md` | Professional bug bounty reports |
| `dashboard/data.js` | Dashboard data |
| `dashboard/index.html` | Command Center UI |

## Directory Structure

```
SystemFixer/
├── main.py                    ← Single entry point
├── system.py                  ← Legacy entry (delegates to main.py)
├── programs.json              ← Bug bounty targets
├── requirements.txt
├── scanner/
│   └── scan.py               ← Live HTTP vulnerability scanner
├── system_fixer/
│   ├── pipeline.py           ← Main analysis pipeline
│   ├── findings_loader.py
│   ├── findings_normalizer.py
│   ├── false_positive_filter.py
│   ├── severity_scoring.py
│   ├── rules_engine.py
│   ├── intelligence_enricher.py
│   ├── money_filter.py
│   ├── money_ranker.py
│   ├── report_generator.py   ← Professional bug bounty reports
│   ├── dashboard_writer.py
│   └── output_writer.py
├── data/                     ← Per-program scan files + scan_results.json
├── output/                   ← final_findings.json
├── reports/                  ← Markdown reports (one per program per day)
├── dashboard/
│   ├── index.html            ← Command Center UI
│   └── data.js               ← Auto-generated findings data
└── .github/workflows/        ← Autonomous GitHub Actions
```
