#!/usr/bin/env python3
"""
system.py — legacy entry point, delegates to main.py.
Kept for backward compatibility.
"""
import subprocess, sys, os
subprocess.run([sys.executable, os.path.join(os.path.dirname(__file__), "main.py")] + sys.argv[1:])
