"""
intelligence_enricher.py — enriches findings with tags derived from:
  1. vuln_class field (set by scanner)
  2. Title/description keyword matching
  3. Target analysis
"""

# Map vuln_class values → intelligence tags
VULN_CLASS_TAGS = {
    "cors":             ["cors", "data_exposure"],
    "jwt":              ["jwt", "auth_bypass"],
    "open_redirect":    ["open_redirect"],
    "ssrf":             ["ssrf"],
    "info_disclosure":  ["info_disclosure"],
    "rce":              ["rce"],
    "sqli":             ["sqli"],
    "idor":             ["idor"],
    "xss":              ["xss"],
    "csrf":             ["csrf"],
}

# Keyword → tag mapping for text-based enrichment
KEYWORD_TAGS = {
    "injection":              "injection",
    "xss":                    "xss",
    "cross-site scripting":   "xss",
    "csrf":                   "csrf",
    "authentication":         "auth_bypass",
    "auth bypass":            "auth_bypass",
    "rce":                    "rce",
    "remote code execution":  "rce",
    "sql injection":          "sqli",
    "sqli":                   "sqli",
    "exposed":                "data_exposure",
    "leak":                   "data_exposure",
    "disclosure":             "data_exposure",
    "cors":                   "cors",
    "cross-origin":           "cors",
    "jwt":                    "jwt",
    "token forgery":          "jwt",
    "open redirect":          "open_redirect",
    "redirect":               "open_redirect",
    "ssrf":                   "ssrf",
    "server-side request":    "ssrf",
    "idor":                   "idor",
    "insecure direct":        "idor",
    "hsts":                   "hsts",
    "clickjacking":           "clickjacking",
    "csp":                    "csp",
    "content security":       "csp",
    "permission":             "permissions",
    "stack trace":            "info_disclosure",
    "version":                "info_disclosure",
    "header":                 "header_misconfiguration",
}

HIGH_VALUE_TAGS = {"rce", "sqli", "jwt", "auth_bypass", "ssrf", "cors", "idor", "xss"}


def enrich_findings(findings):
    enriched = []

    for f in findings:
        tags = set()

        # 1. vuln_class → tags (most reliable, set by scanner)
        vc = f.get("vuln_class", "") or ""
        if vc in VULN_CLASS_TAGS:
            tags.update(VULN_CLASS_TAGS[vc])

        # 2. keyword matching on title + description
        text = " ".join([
            f.get("title", ""),
            f.get("description", ""),
            f.get("impact", ""),
        ]).lower()

        for keyword, tag in KEYWORD_TAGS.items():
            if keyword in text:
                tags.add(tag)

        # 3. Infer from title patterns
        title = f.get("title", "").lower()
        if "missing" in title:
            tags.add("header_misconfiguration")
        if "hsts" in title:
            tags.add("hsts")
        if "csp" in title or "content-security" in title:
            tags.add("csp")
        if "x-frame" in title or "clickjack" in title:
            tags.add("clickjacking")

        tag_list = sorted(tags)
        is_high_value = bool(tags & HIGH_VALUE_TAGS)

        f["intelligence"] = {
            "tags":         tag_list,
            "tag_count":    len(tag_list),
            "is_high_value": is_high_value,
        }

        enriched.append(f)

    tagged = sum(1 for f in enriched if f["intelligence"]["tag_count"] > 0)
    print(f"[intelligence_enricher] Enriched {len(enriched)} findings ({tagged} with tags)")
    return enriched
