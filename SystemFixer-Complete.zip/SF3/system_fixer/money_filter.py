"""
money_filter.py — score each finding then apply threshold filter.

Money score is computed from severity + exploitability + intelligence tags.
Scores are on a 0–100 scale.
"""

SEVERITY_BASE = {
    "CRITICAL": 80,
    "HIGH": 60,
    "MEDIUM": 40,
    "LOW": 20,
    "UNRATED": 10,
}

HIGH_VALUE_TAGS = {"rce", "sqli", "jwt", "auth_bypass", "ssrf", "cors", "idor"}


def compute_money_score(finding):
    sev = finding.get("severity", "UNRATED").upper()
    base = SEVERITY_BASE.get(sev, 10)

    # Exploitability bonus (0–10 scale → 0–20 bonus)
    exploit = finding.get("exploitability_score", 1)
    exploit_bonus = min(int(exploit) * 2, 20)

    # Intelligence tag bonus
    intel = finding.get("intelligence", {})
    tags = set(intel.get("tags", []))
    vuln_class = finding.get("vuln_class", "")
    if vuln_class:
        tags.add(vuln_class)
    tag_bonus = 15 if tags & HIGH_VALUE_TAGS else 0

    score = min(base + exploit_bonus + tag_bonus, 100)
    return score


def apply_money_filter(findings, min_score=0):
    """Score every finding then filter by threshold."""
    scored = []
    for f in findings:
        if f.get("money_score", None) is None:
            f["money_score"] = compute_money_score(f)
        if f["money_score"] >= min_score:
            scored.append(f)

    print(f"[money_filter] {len(scored)}/{len(findings)} findings passed "
          f"money filter (min_score={min_score})")
    return scored
