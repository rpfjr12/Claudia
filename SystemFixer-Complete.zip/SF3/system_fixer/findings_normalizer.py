"""
findings_normalizer.py — normalizes raw findings while preserving ALL original fields.

CRITICAL: Every field from the raw finding must survive normalization.
Fields like fingerprint, date, vuln_class are required downstream.
"""

def normalize_findings(findings):
    normalized = []

    for f in findings:
        # Start with ALL original fields so nothing is lost
        n = dict(f)

        # Ensure required fields have safe defaults
        n["program"]              = f.get("program", "Unknown Program")
        n["target"]               = f.get("target", "Unknown Target")
        n["title"]                = f.get("title", "Untitled Finding")
        n["description"]          = f.get("description", "")
        n["reproduction_steps"]   = f.get("reproduction_steps", "")
        n["impact"]               = f.get("impact", "")
        n["severity"]             = f.get("severity", "UNRATED")
        n["exploitability_score"] = f.get("exploitability_score", 1)
        n["fingerprint"]          = f.get("fingerprint", "")
        n["date"]                 = f.get("date", "")
        n["vuln_class"]           = f.get("vuln_class", "")
        n["source"]               = f.get("source", "scanner")

        # Keep raw copy for debugging
        n["raw"] = f

        normalized.append(n)

    print(f"[findings_normalizer] Normalized {len(normalized)} findings")
    return normalized
