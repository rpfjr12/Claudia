"""
dashboard_writer.py — embeds all findings data inline into index.html.
Self-contained file, opens by double-click, no server required.
"""
import json
import os
from collections import Counter
from datetime import datetime, timezone

DASHBOARD_DIR  = "dashboard"
DASHBOARD_HTML = os.path.join(DASHBOARD_DIR, "index.html")
DASHBOARD_DATA = os.path.join(DASHBOARD_DIR, "data.js")

DATA_START = "/* __SYSTEMFIXER_DATA_START__ */"
DATA_END   = "/* __SYSTEMFIXER_DATA_END__ */"


def _safe(f):
    raw = f.get("raw", {})
    return {
        "severity":           f.get("severity",           raw.get("severity", "UNRATED")),
        "title":              f.get("title",               raw.get("title", "")),
        "target":             f.get("target",              raw.get("target", "")),
        "program":            f.get("program",             raw.get("program", "")),
        "date":               f.get("date",                raw.get("date", "")),
        "money_score":        f.get("money_score", 0),
        "fingerprint":        f.get("fingerprint",         raw.get("fingerprint", "")),
        "intelligence":       f.get("intelligence", {}),
        "description":        f.get("description",         raw.get("description", "")),
        "reproduction_steps": f.get("reproduction_steps",  raw.get("reproduction_steps", "")),
        "impact":             f.get("impact",              raw.get("impact", "")),
        "vuln_class":         f.get("vuln_class",          raw.get("vuln_class", "")),
        "exploitability_score": f.get("exploitability_score", raw.get("exploitability_score", 0)),
        "source":             f.get("source", "scanner"),
        "evidence":           f.get("evidence", {}),
    }


def _summary(findings):
    programs, vc, dc = {}, Counter(), Counter()
    for f in findings:
        p = f.get("program", "Unknown")
        if p not in programs:
            programs[p] = {"name": p, "count": 0, "high_count": 0, "top_score": 0}
        programs[p]["count"] += 1
        if f.get("severity") in ("HIGH", "CRITICAL"):
            programs[p]["high_count"] += 1
        programs[p]["top_score"] = max(programs[p]["top_score"], f.get("money_score", 0))
        vc[f.get("vuln_class") or "header_misconfiguration"] += 1
        d = (f.get("date") or "")[:10]
        if d: dc[d] += 1
    return {
        "generated":   datetime.now(timezone.utc).isoformat() + "Z",
        "total":       len(findings),
        "by_severity": dict(Counter(f.get("severity", "UNRATED") for f in findings)),
        "programs":    list(programs.values()),
        "vuln_classes":[{"label": k, "count": v}
                        for k, v in sorted(vc.items(), key=lambda x: -x[1])],
        "date_series": [{"date": k, "count": v}
                        for k, v in sorted(dc.items())],
    }


def write_dashboard(findings):
    os.makedirs(DASHBOARD_DIR, exist_ok=True)
    safe = [_safe(f) for f in findings]
    summ = _summary(findings)
    fj   = json.dumps(safe, separators=(',', ':'))
    sj   = json.dumps(summ, separators=(',', ':'))
    new_block = f"{DATA_START}\nconst SF_F={fj};\nconst SF_S={sj};\n{DATA_END}"

    # ── Inject into index.html using plain string split (avoids regex backslash issues) ──
    if os.path.exists(DASHBOARD_HTML):
        html = open(DASHBOARD_HTML, encoding="utf-8").read()
        if DATA_START in html and DATA_END in html:
            before = html[:html.index(DATA_START)]
            after  = html[html.index(DATA_END) + len(DATA_END):]
            html   = before + new_block + after
        else:
            # Fallback: replace placeholder tokens
            html = html.replace("__FINDINGS__", fj).replace("__SUMMARY__", sj)
        open(DASHBOARD_HTML, "w", encoding="utf-8").write(html)
        print(f"[dashboard_writer] Injected {len(findings)} findings → {DASHBOARD_HTML}")
    else:
        print(f"[dashboard_writer] WARNING: {DASHBOARD_HTML} not found")

    # ── Also write data.js ─────────────────────────────────────────────────
    open(DASHBOARD_DATA, "w", encoding="utf-8").write(
        f"// Auto-generated — {summ['generated']}\n"
        f"window.SF_FINDINGS={fj};\nwindow.SF_SUMMARY={sj};\n"
    )
    print(f"[dashboard_writer] Also wrote {DASHBOARD_DATA}")
