"""
severity_engine.py — normalizes severity labels, applies program rules,
and exports meets_severity_threshold for other modules.
"""
from system_fixer.severity_scoring import score_severity
from system_fixer.rules_engine import apply_rules_to_all

# Severity order for threshold comparisons
_SEV_ORDER = {"CRITICAL": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1, "UNRATED": 0}

# Default minimum severity thresholds per program (override in program_rules.json)
_DEFAULT_THRESHOLD = "LOW"
_PROGRAM_THRESHOLDS = {}


def meets_severity_threshold(program: str, severity: str) -> bool:
    """Return True if severity meets or exceeds the program's minimum threshold."""
    threshold = _PROGRAM_THRESHOLDS.get(program.lower(), _DEFAULT_THRESHOLD)
    return _SEV_ORDER.get(severity.upper(), 0) >= _SEV_ORDER.get(threshold.upper(), 1)


def run_severity_engine(findings):
    print("[severity_engine] Starting severity engine...")
    findings = score_severity(findings)
    print("[severity_engine] Severity normalized")
    findings = apply_rules_to_all(findings)
    print("[severity_engine] Program rules applied")
    print("[severity_engine] Severity engine complete")
    return findings
