#!/usr/bin/env python3
"""
main.py — SystemFixer single entry point.

Usage:
    python main.py              # scan + pipeline (full run)
    python main.py --scan-only  # scanner only
    python main.py --pipe-only  # pipeline only (uses existing scan data)
    python main.py --status     # show current findings count
"""
import sys
import os
import subprocess
import json
from datetime import datetime, timezone

REPO_ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, REPO_ROOT)
os.chdir(REPO_ROOT)


def banner():
    print("=" * 60)
    print("  SystemFixer — Autonomous Vulnerability Analysis System")
    print(f"  {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S')} UTC")
    print("=" * 60)


def run_scanner():
    print("\n[main] ── STEP 1: Scanner ──────────────────────────────")
    env = {**os.environ, "PYTHONPATH": REPO_ROOT}
    result = subprocess.run(
        [sys.executable, "scanner/scan.py"],
        env=env, cwd=REPO_ROOT,
    )
    if result.returncode != 0:
        print("[main] Scanner failed — aborting")
        sys.exit(1)


def run_pipeline():
    print("\n[main] ── STEP 2: Pipeline ─────────────────────────────")
    env = {**os.environ, "PYTHONPATH": REPO_ROOT}
    result = subprocess.run(
        [sys.executable, "-m", "system_fixer.pipeline"],
        env=env, cwd=REPO_ROOT,
    )
    if result.returncode != 0:
        print("[main] Pipeline failed")
        sys.exit(1)


def show_status():
    final = os.path.join(REPO_ROOT, "output", "final_findings.json")
    scan  = os.path.join(REPO_ROOT, "data", "scan_results.json")
    for path, label in [(final, "Processed findings"), (scan, "Raw scan results")]:
        if os.path.exists(path):
            try:
                with open(path) as f:
                    data = json.load(f)
                counts = {}
                for item in data:
                    s = item.get("severity", "UNRATED")
                    counts[s] = counts.get(s, 0) + 1
                print(f"\n{label}: {len(data)} total")
                for sev in ["CRITICAL", "HIGH", "MEDIUM", "LOW", "UNRATED"]:
                    if counts.get(sev):
                        print(f"  {sev}: {counts[sev]}")
            except Exception as e:
                print(f"  Error reading {path}: {e}")
        else:
            print(f"\n{label}: not found ({path})")

    reports_dir = os.path.join(REPO_ROOT, "reports")
    if os.path.isdir(reports_dir):
        reports = [f for f in os.listdir(reports_dir) if f.endswith(".md")]
        print(f"\nReports: {len(reports)} files in reports/")

    dashboard = os.path.join(REPO_ROOT, "dashboard", "data.js")
    if os.path.exists(dashboard):
        mtime = datetime.fromtimestamp(os.path.getmtime(dashboard), timezone.utc)
        print(f"Dashboard: last updated {mtime.strftime('%Y-%m-%d %H:%M:%S')} UTC")


def main():
    banner()
    args = sys.argv[1:]

    if "--status" in args:
        show_status()
        return

    if "--pipe-only" in args:
        run_pipeline()
    elif "--scan-only" in args:
        run_scanner()
    else:
        # Default: full run
        run_scanner()
        run_pipeline()

    print("\n[main] ── Complete ─────────────────────────────────────")
    show_status()
    print("\n[main] Open dashboard/index.html in your browser to view results.")


if __name__ == "__main__":
    main()
