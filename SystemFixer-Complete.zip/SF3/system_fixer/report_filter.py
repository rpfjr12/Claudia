"""
report_filter.py — filters findings eligible for report generation.

Requires only the minimum fields needed for a usable report.
Does NOT require intelligence tags (enrichment may vary by finding type).
"""

def filter_for_reporting(findings):
    filtered = []

    for f in findings:
        # Must have a title
        if not f.get("title"):
            continue
        # Must have a target
        if not f.get("target"):
            continue
        # Must have a description
        if not f.get("description"):
            continue
        # Must have reproduction steps
        if not f.get("reproduction_steps"):
            continue
        # Must have a program name
        if not f.get("program"):
            continue
        # Must not be explicitly excluded by rules engine
        if f.get("excluded_by_rules"):
            continue
        # Must have severity assigned
        sev = f.get("severity", "")
        if not sev or sev == "UNRATED":
            continue

        filtered.append(f)

    removed = len(findings) - len(filtered)
    print(f"[report_filter] {len(filtered)} findings eligible for reporting "
          f"({removed} excluded)")
    return filtered
