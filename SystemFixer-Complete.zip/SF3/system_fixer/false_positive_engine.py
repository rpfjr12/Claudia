"""
false_positive_engine.py — rule-based false positive detection.
Accepts an optional program argument for compatibility.
"""

def is_false_positive(finding, program=None):
    """Return True if the finding is likely a false positive."""
    title = finding.get("title", "").lower()
    desc  = finding.get("description", "").lower()

    # Hard noise filters
    if "test" in title and "example" in desc:
        return True
    if any(k in title for k in ("dummy", "placeholder", "lorem ipsum")):
        return True
    if "no vulnerability" in desc or "scanner error" in desc:
        return True
    if not finding.get("target") or not finding.get("title"):
        return True

    return False
